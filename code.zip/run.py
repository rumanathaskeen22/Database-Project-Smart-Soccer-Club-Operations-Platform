from club import club
from club.controllers import admin_controller, player_controller, manager_controller, team_controller 
from club.controllers import signin_controller, practice_controller, venue_controller, timeslot_controller
from club.controllers import match_controller




if __name__ == "__main__":    
    club.run(debug=True)