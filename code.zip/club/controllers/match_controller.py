import time
from flask import render_template, request, redirect, url_for, session
from club import club
from club.models.admin import Admin
from club.models.manager import Manager
from club.models.player import Player
from club.models.match import Match
from club.models.team import Team
from club.models.venue import Venue
from club.models.timeslot import Timeslot
from club.models.practice import Practice

from datetime import time
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime
from bson import ObjectId


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)






@club.route('/manage_matches')
def manage_matches(): 
        venues = list(Venue.get_all())
        teams = list(Team.get_all())
        
        return render_template('matches/manage_matches.html', venues=venues, teams=teams)





@club.route('/schedule_match', methods=['POST'])
def schedule_match():

    # Your existing code to check form data
    data = {
        'home_team': ObjectId(request.form['home_team']),
        'away_team': ObjectId(request.form['away_team']),
        'venue_id': ObjectId(request.form['venue']),
        'match_date': request.form['match_date'],
        'start_time': request.form['start_time'],
        'end_time': request.form['end_time'],
        'type': 'tournament',
        'result': 'pending',
        'status': 'scheduled',
        'created_at': datetime.now(),
        'updated_at': datetime.now()
    }

    Match.create(data)
    flash('Practice match scheduled successfully.', 'success')
    return redirect(url_for('admin_home'))


@club.route('/set_match_winner/<match_id>', methods=['POST'])
def set_match_winner(match_id):
    winner = request.form.get('winner')
    
    # Assuming a method to find the match by ID and update it
    match = Match.find_by_id(ObjectId(match_id))
    if not match:
        flash('Match not found.', 'error')
        return redirect(url_for('admin_home'))

    # Assuming 'winner' is stored directly in the match document
    Match.update_result(ObjectId(match_id), winner)
    Match.update_status(ObjectId(match_id), 'completed')

    flash('Match result updated successfully.', 'success')
    return redirect(url_for('admin_home'))



@club.route('/admin_old_games')
def admin_old_games():
    matches = Match.get_all_completed()
    practice_matches = Practice.get_all_completed()
    matches = list(matches)
    practice_matches = list(practice_matches) 
    practice_matches2 = []
    for match in practice_matches:
        team1 = Team.get_by_id(match['team1_id'])
        team2 = Team.get_by_id(match['team2_id'])
        venue = Venue.get_by_id(match['venue_id']) 
        match['team1_name'] = team1['team_name']  # Assuming your Team model has a 'name' field
        match['team2_name'] = team2['team_name']
        match['venue_name'] = venue['venue_name']  # Assuming your Venue model has a 'name' field
        practice_matches2.append(match)
    
    matches2 = []
    for match in matches:
        team1 = Team.get_by_id(match['home_team'])
        team2 = Team.get_by_id(match['away_team'])
        venue = Venue.get_by_id(match['venue_id']) 
        match['team1_name'] = team1['team_name']
        match['team2_name'] = team2['team_name']
        match['venue_name'] = venue['venue_name']
        matches2.append(match)
    print(matches2)
    return render_template('matches/admin_old_games.html', matches=matches, practice_matches=practice_matches2  )