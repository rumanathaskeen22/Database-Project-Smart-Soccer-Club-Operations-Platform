from flask import render_template, request, redirect, url_for, session
from club import club
from club.models.admin import Admin
from club.models.manager import Manager
from club.models.player import Player
from club.models.match import Match
from club.models.team import Team
from club.models.venue import Venue
from club.models.timeslot import Timeslot
from club.models.practice import Practice

from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@club.route("/manage_venues")
def manage_venues():
    venues = Venue.get_all()
    return render_template("venues/manage_venues.html", venues=venues)


@club.route("/register_venue", methods=["POST"])
def register_venue():
    venue_name = request.form["venue_name"]
    address = request.form["location"]
    capacity = request.form["capacity"]
    phone = request.form["contact_number"] 
    data = {
        "venue_name": venue_name,
        "address": address,
        "capacity": capacity,
        "phone": phone
    
    }
    venue = Venue.create(data) 
    flash("Venue registered successfully")
    return redirect(url_for("manage_venues"))