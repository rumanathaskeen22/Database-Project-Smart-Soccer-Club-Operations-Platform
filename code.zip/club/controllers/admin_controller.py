from flask import render_template, request, redirect, url_for, session
from club import club
from club.models.admin import Admin
from club.models.manager import Manager
from club.models.player import Player
from club.models.match import Match
from club.models.team import Team
from club.models.venue import Venue
from club.models.timeslot import Timeslot
from club.models.practice import Practice
from flask import jsonify
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@club.route('/admin_home')
def admin_home():
    # Fetch practice matches, this is pseudo-code, adjust according to your actual data fetching logic
    practice_matches_raw = Practice.get_all_scheduled()  # Assuming this method returns all scheduled practice matches
    
    # Populate team names and venue names
    practice_matches = []
    for match in practice_matches_raw:
        team1 = Team.get_by_id(match['team1_id'])
        team2 = Team.get_by_id(match['team2_id'])
        venue = Venue.get_by_id(match['venue_id']) 
        match['team1_name'] = team1['team_name']  # Assuming your Team model has a 'name' field
        match['team2_name'] = team2['team_name']
        match['venue_name'] = venue['venue_name']  # Assuming your Venue model has a 'name' field
        practice_matches.append(match)

    # Similar logic for tournaments, if needed
    final_tournaments = []
    tournaments = Match.get_all_scheduled()   
    for match in tournaments:
        team1 = Team.get_by_id(match['home_team'])
        team2 = Team.get_by_id(match['away_team'])
        venue = Venue.get_by_id(match['venue_id']) 
        match['home_team_name'] = team1['team_name']
        match['away_team_name'] = team2['team_name']
        match['venue_name'] = venue['venue_name']
        final_tournaments.append(match)
    return render_template('admins/home.html', practice_matches=practice_matches, tournaments=final_tournaments)

@club.route('/admin_manage_managers')
def admin_manage_managers():
    managers = Manager.get_all()
    managers = list(managers)    
    return render_template('admins/manage_managers.html', managers=managers)


@club.route('/admin_manage_players')
def admin_manage_players():
    players = Player.get_all()
    players = list(players) 
    return render_template('admins/manage_players.html', players=players)



@club.route('/update-manager-status', methods=['POST'])
def update_manager_status():
    try: 
        data = request.json  # Access the JSON data sent in the request body
        manager_id = data['managerId']  # Make sure these keys match what you send from the frontend
        status = data['status'] 
        Manager.update_status(manager_id, status)  # Assuming this is a method of your Manager model that does the update
        return jsonify({'message': 'Status updated successfully'}), 200
    except Exception as e:
        logger.error(f"Error during update manager status: {str(e)}")
        return jsonify({'message': 'Internal Server Error'}), 500



















@club.route('/admin_signup', methods=['GET', 'POST'])
def admin_signup():
    try: 
        if request.method == 'POST': 
            email = request.form.get("email").strip()
            if Admin.exists_by_email(email):
                return "Email already reged", 400

            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()

            if password != confirm_password:
                return "Passwords do not match", 400

            data = {
                "username": request.form.get("username").strip(),
                "email": email,
                "phone_number": request.form.get("phone").strip(),
                "password": generate_password_hash(password),
                "createdAt": datetime.now()
            } 
            Admin.create(data)
            return redirect(url_for('signin'))

        return render_template('signin_signup/admin_signup.html')
    except Exception as e:
        logger.error(f"Error during admin registration: {str(e)}")
        return "Internal Server Error", 500

