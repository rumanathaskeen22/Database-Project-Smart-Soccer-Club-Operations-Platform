import time
from flask import render_template, request, redirect, url_for, session
from club import club
from club.models.admin import Admin
from club.models.manager import Manager
from club.models.player import Player
from club.models.match import Match
from club.models.team import Team
from club.models.venue import Venue
from club.models.timeslot import Timeslot
from club.models.practice import Practice

from datetime import time
from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime
from bson import ObjectId


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@club.route('/manage_practice_matches')
def manage_practice_matches(): 
        venues = list(Venue.get_all())
        teams = list(Team.get_all())
        
        return render_template('matches/manage_practice_matches.html', venues=venues, teams=teams)


@club.route('/schedule_practice_match', methods=['POST'])
def schedule_practice_match():
    # Existing code to parse form data
    start_datetime = datetime.strptime(request.form.get('start_time'), '%Y-%m-%dT%H:%M')
    date = start_datetime.date()  # Date part
    start_time = start_datetime.time()  # Time pa
    datetime_for_mongo = datetime.combine(date, time.min)

    # Your existing code to check form data
    data = {
        'team1_id': ObjectId(request.form['team1']),
        'team2_id': ObjectId(request.form['team2']),
        'venue_id': ObjectId(request.form['venue']),
        'date': datetime_for_mongo,  # Storing combined datetime
        'start_time': start_time.strftime('%H:%M:%S'),  # Storing time as string
        'type': 'practice',
        'result': 'pending',
        'status': 'scheduled',
        'created_at': datetime.now()
    }

    Practice.create(data)
    flash('Practice match scheduled successfully.', 'success')
    return redirect(url_for('admin_home'))


@club.route('/set_prac_match_winner/<match_id>', methods=['POST'])
def set_prac_match_winner(match_id):
    winner = request.form.get('winner')
    match = Practice.find_by_id(ObjectId(match_id))
    if not match:
        flash('Match not found.', 'error')
        return redirect(url_for('admin_home'))
    Practice.update_result(ObjectId(match_id), winner)
    Practice.update_status(ObjectId(match_id), 'completed')

    flash('Match result updated successfully.', 'success')
    return redirect(url_for('admin_home'))
