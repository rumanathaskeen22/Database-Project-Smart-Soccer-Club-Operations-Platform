from flask import render_template, request, redirect, url_for, session
from club import club
from club.models.admin import Admin
from club.models.manager import Manager
from club.models.player import Player
from club.models.match import Match
from club.models.team import Team
from club.models.venue import Venue
from club.models.timeslot import Timeslot
from club.models.practice import Practice

from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO) 
logger = logging.getLogger(__name__)



@club.route('/manager_home')
def manager_home():
    practice_matches_raw = Practice.get_all_scheduled()
    
    # Populate team names and venue names
    practice_matches = []
    for match in practice_matches_raw:
        team1 = Team.get_by_id(match['team1_id'])
        team2 = Team.get_by_id(match['team2_id'])
        venue = Venue.get_by_id(match['venue_id']) 
        match['team1_name'] = team1['team_name'] 
        match['team2_name'] = team2['team_name']
        match['venue_name'] = venue['venue_name']  
        practice_matches.append(match)

    # Similar logic for tournaments, if needed
    tournaments_raw = Match.get_all_scheduled()
    tournaments = []
    for match in tournaments_raw:
        team1 = Team.get_by_id(match['home_team'])
        team2 = Team.get_by_id(match['away_team'])
        venue = Venue.get_by_id(match['venue_id']) 
        match['team1_name'] = team1['team_name']
        match['team2_name'] = team2['team_name']
        match['venue_name'] = venue['venue_name']
        tournaments.append(match)
        
    print("=====================================")
    print(tournaments)

    return render_template('managers/home.html', practice_matches=practice_matches, tournaments=tournaments)




@club.route('/manage_my_team')
def manage_my_team():
    if Team.exists_by_manager_id(session['manager_id']):
        team = Team.get_by_manager_id(session['manager_id']) 
        player_details=[]
        for player_id in team["players"]:
            player = Player.get_by_id(player_id)
            if player:
                player_details.append(player)
        return render_template('managers/manage_my_team.html', team=team, player_details=player_details)
    else:
        return render_template('managers/register_team.html') 

@club.route('/update_player_role', methods=['POST'])
def update_player_role():
    try: 
        player_id = request.form.get("player_id") 
        position = request.form.get("role") 
        Player.update_position(player_id, position)
        return redirect(url_for('manage_my_team'))
    except Exception as e:
        logger.error(f"Error during updating player role: {str(e)}")
        return "Internal Server Error", 500

@club.route('/register_team', methods=['POST'])
def register_team():
    try: 
        data = {
            "manager_id": session['manager_id'],
            "team_name": request.form.get("team_name"),
            "coach_name": request.form.get("coach_name"),
            "address": request.form.get("address"),
            "players": [],
            "createdAt": datetime.now()
        }
        Team.create(data)
        return redirect(url_for('manage_my_team'))
    except Exception as e:
        logger.error(f"Error during team registration: {str(e)}")
        return "Internal Server Error", 500

# view players without a team
@club.route('/view_players_without_team')
def view_players_without_team():
    team_address = Team.get_address_by_manager_id(session['manager_id']) 
    players = Player.get_all_without_team_and_same_address(team_address)

    players = list(players)
    return render_template('managers/view_players_without_team.html', players=players)



@club.route('/assign_team', methods=['POST'])
def assign_team():
    try:
        manager_id = request.form.get("manager_id")   
        player_id = request.form.get("player_id")  # Gets player_id from the form
        Team.assign_player_to_managers_team(manager_id, player_id)
        team = Team.get_by_manager_id(manager_id)  
        Player.assign_team(player_id, team["_id"])
        return redirect(url_for('view_players_without_team'))
    except Exception as e:
        logger.error(f"Error during assigning team: {str(e)}")
        return "Internal Server Error", 500


@club.route('/signup_manager', methods=['GET', 'POST'])
def signup_manager():  
    try:
        if request.method == 'POST':  
            email = request.form.get("email").strip()
            if Manager.exists_by_email(email):
                return "Email already reged", 400

            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()

            if password != confirm_password:
                return "Passwords do not match", 400

            data = {
                "manager_name": request.form.get("manager_name").strip(),
                "company": request.form.get("company").strip(),  
                "email": email,
                "phone_number": request.form.get("phone_number").strip(),
                "password": generate_password_hash(password),
                "createdAt": datetime.now(),
                "status": "Pending"

            } 
            Manager.create(data)
            return redirect(url_for('signin'))
        
        return render_template('signin_signup/manager_signup.html')
    except Exception as e:
        logger.error(f"Error during manager registration: {str(e)}")
        return "Internal Server Error", 500
