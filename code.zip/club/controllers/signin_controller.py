from flask import render_template, request, redirect, url_for, session
from club import club
from club.models.admin import Admin
from club.models.manager import Manager
from club.models.player import Player
from club.models.match import Match
from club.models.team import Team
from club.models.venue import Venue
from club.models.timeslot import Timeslot
from club.models.practice import Practice

from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



@club.route('/',)
def home():
    return render_template('index.html')











@club.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST': 
        email = request.form.get("email").strip()   
        password = request.form.get("password").strip()
        # check if player exists in the player database
        if Player.exists_by_email(email):
            player = Player.get_by_email(email)
            if check_password_hash(player['password'], password):
                session["player_id"] = str(player['_id'])
                session["player_type"] = "player"
                return redirect(url_for('player_home'))
            else:
                return "Invalid credentials", 400
            
        # check if manager exists in the manager database
        elif Manager.exists_by_email(email):
            manager = Manager.get_by_email(email)
            if check_password_hash(manager['password'], password):
                session["manager_id"] = str(manager['_id'])
                session["manager_type"] = "manager"
                return redirect(url_for('manager_home'))
            else:
                return "Invalid credentials", 400

        # check if admin exists in the admin database
        elif Admin.exists_by_email(email):
            admin = Admin.get_by_email(email)
            if check_password_hash(admin['password'], password):
                session["admin_id"] = str(admin['_id'])
                session["admin_type"] = "admin"
                return redirect(url_for('admin_home'))
            else:
                return "Invalid credentials", 400

    return render_template('signin_signup/signin.html')



@club.route('/logout')
def logout():
    try:
        session.pop('player_id', None)
        session.pop('player_type', None)
        return redirect(url_for('signin'))
    except Exception as e:
        logger.error(f"Error during logout: {str(e)}")
        return "Internal Server Error", 500

