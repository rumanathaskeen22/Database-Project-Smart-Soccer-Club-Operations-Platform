from flask import render_template, request, redirect, url_for, session
from club import club
from club.models.admin import Admin
from club.models.manager import Manager
from club.models.player import Player
from club.models.match import Match
from club.models.team import Team
from club.models.venue import Venue
from club.models.timeslot import Timeslot
from club.models.practice import Practice

from werkzeug.security import generate_password_hash, check_password_hash 
import logging
from bson import ObjectId
from flask import flash
from datetime import datetime


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# playerhome
@club.route('/player_home')
def player_home():
    return render_template('players/home.html')






@club.route('/signup_player', methods=['GET', 'POST'])
def signup_player(): 
    try:
        if request.method == 'POST':   
            email = request.form.get("email").strip()
            if Player.exists_by_email(email):
                return "Email already reged", 400

            password = request.form.get("password").strip()
            confirm_password = request.form.get("confirm_password").strip()

            if password != confirm_password:
                return "Passwords do not match", 400

            data = {
                "first_name": request.form.get("first_name").strip(),
                "last_name": request.form.get("last_name").strip(),
                "email": email,
                "dob": request.form.get("dob").strip(), 
                "position":"",
                "phone_number": request.form.get("phone_number").strip(),
                "address": request.form.get("address").strip(),
                "password": generate_password_hash(password),
                "createdAt": datetime.now(),
                "team_id": None,
            } 
            Player.create(data)
            return redirect(url_for('signin'))

        return render_template('signin_signup/player_signup.html')
    except Exception as e:
        logger.error(f"Error during player registration: {str(e)}")
        return "Internal Server Error", 500

