
from flask import Flask
from flask_pymongo import PyMongo



club = Flask(__name__, template_folder='views', static_folder='static')
# mongo url
club.config["MONGO_URI"] = ""


club.secret_key = "some"

mongo = PyMongo(club)