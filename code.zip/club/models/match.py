from club import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId

class Match:
    collection = mongo.db.matches

    @classmethod
    def get_all(cls):
        return cls.collection.find()
    

    @classmethod
    def find_by_id(cls, id):
        return cls.collection.find_one({'_id': ObjectId(id)})
    
    @classmethod
    def get_by_id(cls, id):
        return cls.collection.find_one({'_id': ObjectId(id)})
    
    @classmethod
    def update_status(cls, id, status):
        cls.collection.update_one({'_id': ObjectId(id)}, {'$set': {'status': status}})
    
    @classmethod
    def update_result(cls, id, result):
        cls.collection.update_one({'_id': ObjectId(id)}, {'$set': {'result': result}})
    @classmethod
    def get_all_scheduled(cls):
        return cls.collection.find({'status': 'scheduled'})
    

    @classmethod
    def get_all_completed(cls):
        return cls.collection.find({'status': 'completed'})
    
    @classmethod
    def get_by_team_id(cls, team_id):
        return cls.collection.find({'team_id': ObjectId(team_id)})
    

    @classmethod
    def create(cls, data):
        cls.collection.insert_one(data)
        