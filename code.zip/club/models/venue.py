from club import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId

class Venue:
    collection = mongo.db.venues


    @classmethod
    def get_all(cls):
        return list(cls.collection.find({}))
    
    @classmethod
    def get_by_id(cls, venue_id):
        return cls.collection.find_one({"_id": ObjectId(venue_id)})
    

    @classmethod
    def create(cls, data):
        cls.collection.insert_one(data)



    @classmethod
    def update(cls, venue_id, data):
        cls.collection.update_one({"_id": ObjectId(venue_id)}, {"$set": data})