from club import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId

class Team:
    collection = mongo.db.teams

    @classmethod
    def get_by_id(cls, team_id):
        return cls.collection.find_one({"_id": ObjectId(team_id)})

    @classmethod
    def get_address_by_manager_id(cls, manager_id): 
        team = cls.collection.find_one({"manager_id": manager_id}) 
        return team["address"]
    @classmethod
    def assign_player_to_managers_team(cls, manager_id, player_id): 
        team = cls.get_by_manager_id(str(manager_id))  
        cls.collection.update_one({"_id": team["_id"]}, {"$push": {"players": player_id}})


    @classmethod
    def exists_by_manager_id(cls, manager_id): 
        return cls.collection.find_one({"manager_id": manager_id}) is not None
    
    @classmethod
    def assign_player(cls, team_id, player_id):
        cls.collection.update_one({"_id": ObjectId(team_id)}, {"$push": {"players": player_id}})

    @classmethod
    def get_by_manager_id(cls, manager_id):  
        return cls.collection.find_one({"manager_id": manager_id})
    

    @classmethod
    def create(cls, data):
        cls.collection.insert_one(data)


    @classmethod
    def get_all(cls):
        return cls.collection.find({})
    
    @classmethod
    def update_status(cls, manager_id, status):
        cls.collection.update_one({"manager_id": ObjectId(manager_id)}, {"$set": {"status": status}})