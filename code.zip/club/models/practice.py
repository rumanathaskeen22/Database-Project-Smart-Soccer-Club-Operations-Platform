from club import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId

class Practice:
    collection = mongo.db.practices

    @classmethod
    def get_all(cls):
        return cls.collection.find()
    
    @classmethod
    def get_all_completed(cls):
        return cls.collection.find({'status': 'completed'})
    
    @classmethod
    def update_result(cls, id, new_result):
        return cls.collection.update({'_id': id}, {'$set': {'result': new_result}})
    

    @classmethod
    def get_all_scheduled(cls):
        return cls.collection.find({'status': 'scheduled'})
    @classmethod
    def find_by_id(cls, id):
        return cls.collection.find_one({'_id': id})

    @classmethod
    def update_status(cls, id, new_status):
        return cls.collection.update({'_id': id}, {'$set': {'status': new_status}})
    
    @classmethod
    def get_by_id(cls, id):
        return cls.collection.find_one({'_id': ObjectId(id)})
    
    @classmethod
    def get_by_team_id(cls, team_id):
        return cls.collection.find({'team_id': ObjectId(team_id)})
    

    @classmethod
    def create(cls, data):
        cls.collection.insert_one(data)
        