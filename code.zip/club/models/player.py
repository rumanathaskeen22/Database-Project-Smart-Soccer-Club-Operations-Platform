from club import mongo
from werkzeug.security import generate_password_hash, check_password_hash
from bson import ObjectId

class Player:
    collection = mongo.db.players

    @classmethod
    def delete(cls, player_id):
        return cls.collection.delete_one({"_id": ObjectId(player_id)})
    

    @classmethod
    def update_position(cls, player_id, position): 
        return cls.collection.update_one({"_id": ObjectId(player_id)}, {"$set": {"position": position}})

    @classmethod
    def get_by_id(cls, player_id):
        return cls.collection.find_one({"_id": ObjectId(player_id)})
    

    @classmethod
    def get_all_without_team_and_same_address(cls, address): 
        return cls.collection.find({
            "team_id": None, 
            "address": {"$regex": f"^{address}$", "$options": "i"}
        })

    @classmethod
    def assign_team(cls, player_id, team_id):
        return cls.collection.update_one({"_id": ObjectId(player_id)}, {"$set": {"team_id": ObjectId(team_id)}})
    
    @classmethod
    def get_all(cls):
        return cls.collection.find()

    @classmethod
    def get_all_without_team(cls):
        return cls.collection.find({"team_id": None})

    @classmethod
    def create(cls, data):
        return cls.collection.insert_one(data)

    @classmethod
    def get_by_email(cls, email):
        return cls.collection.find_one({"email": email})

    @classmethod
    def check_password(cls, player, password):
        return check_password_hash(player["password"], password)

    @classmethod
    def exists_by_email(cls, email):
        return cls.collection.find_one({"email": email}) is not None